import socket
import pyaudio
import threading

def call():
    CHUNK = 1024
    FORMAT = pyaudio.paInt16
    CHANNELS = 1
    RATE = 44100

    # Setup server
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.bind(("0.0.0.0", 5555))
    server_socket.listen(5)
    print("Waiting for connection...")
    conn, addr = server_socket.accept()
    print(f"Connected by {addr}")

    audio = pyaudio.PyAudio()

    # For receiving audio
    stream_in = audio.open(format=FORMAT, channels=CHANNELS, rate=RATE, input=True, frames_per_buffer=CHUNK)

    # For playing received audio
    stream_out = audio.open(format=FORMAT, channels=CHANNELS, rate=RATE, output=True, frames_per_buffer=CHUNK)

    def receive_audio():
        while True:
            try:
                data = conn.recv(CHUNK)
                stream_out.write(data)
            except:
                break

    def send_audio():
        while True:
            try:
                data = stream_in.read(CHUNK)
                conn.sendall(data)
            except:
                break

    threading.Thread(target=receive_audio).start()
    threading.Thread(target=send_audio).start()