import socket
import pyaudio
import threading

def call():
    CHUNK = 1024
    FORMAT = pyaudio.paInt16
    CHANNELS = 1
    RATE = 44100

    # Replace this with your Lubuntu IP
    SERVER_IP = "172.16.0.253"
    PORT = 5555

    client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    client_socket.connect((SERVER_IP, PORT))
    print("Connected to voice server")

    audio = pyaudio.PyAudio()

    # Input from your mic
    stream_in = audio.open(format=FORMAT, channels=CHANNELS, rate=RATE, input=True, frames_per_buffer=CHUNK)

    # Output to your speakers
    stream_out = audio.open(format=FORMAT, channels=CHANNELS, rate=RATE, output=True, frames_per_buffer=CHUNK)

    def receive_audio():
        while True:
            try:
                data = client_socket.recv(CHUNK)
                stream_out.write(data)
            except:
                break

    def send_audio():
        while True:
            try:
                data = stream_in.read(CHUNK)
                client_socket.sendall(data)
            except:
                break

    threading.Thread(target=receive_audio).start()
    threading.Thread(target=send_audio).start()