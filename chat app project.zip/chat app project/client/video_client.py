import socket
import cv2
import pyaudio
import threading
import pickle
import struct

def video_call():
    # ===== Audio config =====
    CHUNK = 1024
    FORMAT = pyaudio.paInt16
    CHANNELS = 1
    RATE = 44100

    # Replace with Lubuntu server IP
    SERVER_IP = "172.16.0.253"

    # ===== Video socket =====
    video_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    video_socket.connect((SERVER_IP, 9999))
    print("[Video] Connected")

    # ===== Audio socket =====
    audio_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    audio_socket.connect((SERVER_IP, 5555))
    print("[Audio] Connected")

    audio = pyaudio.PyAudio()
    stream_in = audio.open(format=FORMAT, channels=CHANNELS, rate=RATE, input=True, frames_per_buffer=CHUNK)
    stream_out = audio.open(format=FORMAT, channels=CHANNELS, rate=RATE, output=True, frames_per_buffer=CHUNK)
    cap = cv2.VideoCapture(0)

    def send_video():
        while True:
            ret, frame = cap.read()
            if not ret:
                break
            data = pickle.dumps(frame)
            msg = struct.pack("Q", len(data)) + data
            try:
                video_socket.sendall(msg)
            except:
                break

    def receive_video():
        data = b""
        payload_size = struct.calcsize("Q")
        while True:
            try:
                while len(data) < payload_size:
                    data += video_socket.recv(4096)
                msg_size = struct.unpack("Q", data[:payload_size])[0]
                data = data[payload_size:]
                while len(data) < msg_size:
                    data += video_socket.recv(4096)
                frame_data = data[:msg_size]
                data = data[msg_size:]
                frame = pickle.loads(frame_data)
                cv2.imshow("Server Camera", frame)
                if cv2.waitKey(1) == ord('q'):
                    break
            except:
                break

    def send_audio():
        while True:
            try:
                data = stream_in.read(CHUNK)
                audio_socket.sendall(data)
            except:
                break

    def receive_audio():
        while True:
            try:
                data = audio_socket.recv(CHUNK)
                stream_out.write(data)
            except:
                break

    threading.Thread(target=send_video).start()
    threading.Thread(target=receive_video).start()
    threading.Thread(target=send_audio).start()
    threading.Thread(target=receive_audio).start()
