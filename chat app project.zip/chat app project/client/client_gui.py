import socket
import threading
from tkinter import * 
from tkinter import scrolledtext, ttk
from voice_client import call
from video_client import video_call

SERVER_IP = "172.16.0.253"
PORT = 12345

client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client_socket.connect((SERVER_IP, PORT))

themes = {
    "light": {
        "bg": "#ffffff",
        "fg": "#000000",
        "input_bg": "#f0f0f0",
        "text_bg": "#e6e6e6"
    },
    "dark": {
        "bg": "#1e1e1e",
        "fg": "#ffffff",
  "input_bg": "#2e2e2e",
        "text_bg": "#333333"
    }
}

current_theme = "dark"


window = Tk()
window.title("Chat Client")
window.geometry("500x500")
photo = PhotoImage(file="sms.png")
window.iconphoto(True, photo)

def apply_theme():
    theme = themes[current_theme]
    window.config(bg=theme["bg"])
    chat_area.config(bg=theme["text_bg"], fg=theme["fg"])
    message_entry.config(bg=theme["input_bg"], fg=theme["fg"], insertbackground=theme["fg"])
    send_button.config(bg=theme["input_bg"], fg=theme["fg"])
    theme_button.config(bg=theme["input_bg"], fg=theme["fg"])
    call_button.config(bg=theme["input_bg"], fg=theme["fg"])
    video_call_button.config(bg=theme["input_bg"], fg=theme["fg"])

chat_area = scrolledtext.ScrolledText(window, state='disabled', wrap= WORD, font=("Segoe UI", 10))
chat_area.pack(padx=10, pady=10, fill=BOTH, expand=True)

entry_frame = Frame(window)
entry_frame.pack(padx=10, pady=5, fill= X)

message_entry = Entry(entry_frame, font=("Segoe UI", 10))
message_entry.pack(side= LEFT, fill=X, expand=True, padx=(0, 5))

def append_message(msg):
    chat_area.config(state='normal')
    chat_area.insert( END, msg + "\n")
    chat_area.config(state='disabled')
    chat_area.yview( END)

def send_message():
    msg = message_entry.get()
    if msg:
        client_socket.send(msg.encode())
        append_message(f"You: {msg}")
        message_entry.delete(0, END)

send_button = Button(entry_frame, text="Send", command=send_message)
send_button.pack(side=RIGHT)

call_button = Button(entry_frame, text="Call", command=call)
call_button.pack(side=RIGHT)

video_call_button = Button(entry_frame, text="Video Call", command=video_call)
video_call_button.pack(side=RIGHT)

def receive_messages():
    while True:
        try:
            data = client_socket.recv(1024).decode()
            if not data:
                break
            append_message(f"Server: {data}")
        except:
            break

def toggle_theme():
    global current_theme
    current_theme = "light" if current_theme == "dark" else "dark"
    apply_theme()

theme_button = Button(window, text="Toggle Theme", command=toggle_theme)
theme_button.pack(pady=5)

threading.Thread(target=receive_messages, daemon=True).start()
apply_theme()

window.mainloop()
client_socket.close()